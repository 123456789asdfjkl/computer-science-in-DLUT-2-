clear 
syms i;
data1=[];
data2=[];
data3=[];
c=1;
data=importdata('Iris.txt');
data=data(:,1:end);
x=data(:,1);
y=data(:,2);
z=data(:,3);
plot3(x,y,z,'*');

matrix=[5.9016,2.7484,4.3935,1.4339;6.8500,3.0737,5.7421,2.0711;5.0060,3.4280,1.4620,0.2460];
[Idx,C,distance]=KMeans(data,3,matrix,500);%����KMeans�㷨
Distance=sum(distance)%�������

%% ��׼ȷ��
c1=Idx(1:50,1);c2=Idx(51:100,1);c3=Idx(101:150,1);
accuracy=(sum(c1==mode(Idx(1:50,1)))+sum(c2==mode(Idx(51:100,1)))+sum(c3==mode(Idx(101:150,1))))/150


%% �������ͼ
for i=1:1:150
     if Idx(i,1)==1
        data1=[data1;data(i,1:3)];
     end
     if Idx(i,1)==2
        data2=[data2;data(i,1:3)];
     end
     if Idx(i,1)==3
        data3=[data3;data(i,1:3)];
    end
 end
plot3(data1(:,1),data1(:,2),data1(:,3),'*r');
hold on;
plot3(data2(:,1),data2(:,2),data2(:,3),'*g');
hold on;
plot3(data3(:,1),data3(:,2),data3(:,3),'*b');
hold on;
plot3(C(:,1),C(:,2),C(:,3),'*k');
