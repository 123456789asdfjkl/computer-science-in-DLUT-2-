package ̹�˴�ս;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LevelSelectPanel extends JPanel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int level;// �ؿ�ֵ
	private GameType type;// ��Ϸģʽ
	private MainFrame frame;// ������
	private String str="1";
	private Image background;// ����ͼƬ
	private JTextField jt=new JTextField();//�ı���
	private JButton bt=new JButton("ȷ��");//ȷ�ϰ�ť
	private int code;

	public LevelSelectPanel(MainFrame frame, GameType type)
	{
		this.frame = frame;
		this.type = type;
		try {
			background = ImageIO.read(new File(ImageUtil.LOGIN_BACKGROUD_IMAGE_URL));// ��ȡ����ͼƬ
		} catch (IOException e) {
			e.printStackTrace();
		}
		jt.setColumns(20);
		bt.setBounds(200,200,50,100);
		add(jt);
		add(bt);
		setVisible(true);
		jt.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent arg0) {
				
			}
			
			@Override
			public void keyReleased(KeyEvent arg0) {
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				code=e.getKeyCode();
				if(code==KeyEvent.VK_ENTER)
				{
					str=jt.getText();
					level=Integer.parseInt(str);
					if(level<=Level.getCount())
					{
						gotoLevelPanel();
					}
					else {
						JOptionPane.showMessageDialog(null, "������Ĺؿ������ԣ�����������", "����",JOptionPane.ERROR_MESSAGE); 
					}
				}
				
			}
		});
		bt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				str=jt.getText();
				level=Integer.parseInt(str);
				if(level<=Level.getCount())
				{
					gotoLevelPanel();
				}
				else {
					JOptionPane.showMessageDialog(null, "������Ĺؿ������ԣ�����������", "����",JOptionPane.ERROR_MESSAGE); 
				}
			}
		});
		
	}
	private void gotoLevelPanel() {
		System.gc();
		this.removeAll();
		this.repaint();
		frame.setPanel(new LevelPanel(level,frame, type));// ��������ת���˹ؿ����
	}
	public void paintComponent(Graphics g)
	{
		g.drawImage(background , 0, 0, getWidth(), getHeight(), this);
		Font font = new Font("����", Font.BOLD, 15);// ��������
		g.setFont(font);// ʹ������
		g.setColor(Color.BLACK);// ʹ�ú�ɫ
		g.drawString("ѡ�أ�0~"+MapEditorPanel.count+")", 160, 25);//����������ʾ
		
	}
	

}
